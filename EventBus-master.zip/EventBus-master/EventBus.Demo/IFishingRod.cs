﻿namespace EventBus.Demo
{
    public interface IFishingRod
    {
        void ThrowHook(FishingMan man);
    }
}